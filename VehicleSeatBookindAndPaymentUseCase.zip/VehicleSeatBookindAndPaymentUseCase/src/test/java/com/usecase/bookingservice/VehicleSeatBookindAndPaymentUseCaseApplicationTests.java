package com.usecase.bookingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleSeatBookindAndPaymentUseCaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
